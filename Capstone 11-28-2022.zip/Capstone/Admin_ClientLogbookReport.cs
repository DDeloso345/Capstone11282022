﻿using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;

namespace Capstone
{
    public partial class Admin_ClientLogbookReport : Form
    {
        public Admin_ClientLogbookReport()
        {
            InitializeComponent();
        }
    }
}
