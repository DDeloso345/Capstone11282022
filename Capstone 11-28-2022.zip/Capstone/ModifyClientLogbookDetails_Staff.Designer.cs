﻿
namespace Capstone
{
    partial class ModifyClientLogbookDetails_Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.refbtn = new System.Windows.Forms.PictureBox();
            this.logbk_timetxt = new System.Windows.Forms.Label();
            this.logbk_datetxt = new System.Windows.Forms.DateTimePicker();
            this.idtxt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.logbk_mntxt = new System.Windows.Forms.TextBox();
            this.logbk_lntxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.logbk_clr_btn = new System.Windows.Forms.Button();
            this.crit_cmb = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dgv_clientlogbook = new System.Windows.Forms.DataGridView();
            this.logbk_upd_btn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.logbk_numb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.logbk_pnl = new System.Windows.Forms.Label();
            this.logbk_fntxt = new System.Windows.Forms.TextBox();
            this.logbk_addresstxt = new System.Windows.Forms.TextBox();
            this.logbook_pnl = new System.Windows.Forms.Panel();
            this.searchbtn = new System.Windows.Forms.Button();
            this.searchtxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.refbtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_clientlogbook)).BeginInit();
            this.logbook_pnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // refbtn
            // 
            this.refbtn.Image = global::Capstone.Properties.Resources.pngwing_com;
            this.refbtn.Location = new System.Drawing.Point(847, 30);
            this.refbtn.Name = "refbtn";
            this.refbtn.Size = new System.Drawing.Size(25, 25);
            this.refbtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.refbtn.TabIndex = 223;
            this.refbtn.TabStop = false;
            this.refbtn.Click += new System.EventHandler(this.refbtn_Click);
            // 
            // logbk_timetxt
            // 
            this.logbk_timetxt.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logbk_timetxt.Location = new System.Drawing.Point(167, 215);
            this.logbk_timetxt.Name = "logbk_timetxt";
            this.logbk_timetxt.Size = new System.Drawing.Size(197, 22);
            this.logbk_timetxt.TabIndex = 30;
            this.logbk_timetxt.Text = "[Time Details Placeholder]";
            // 
            // logbk_datetxt
            // 
            this.logbk_datetxt.Location = new System.Drawing.Point(166, 192);
            this.logbk_datetxt.Name = "logbk_datetxt";
            this.logbk_datetxt.Size = new System.Drawing.Size(200, 20);
            this.logbk_datetxt.TabIndex = 29;
            // 
            // idtxt
            // 
            this.idtxt.AutoSize = true;
            this.idtxt.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idtxt.Location = new System.Drawing.Point(162, 34);
            this.idtxt.Name = "idtxt";
            this.idtxt.Size = new System.Drawing.Size(64, 22);
            this.idtxt.TabIndex = 27;
            this.idtxt.Text = "[ID Txt]";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 22);
            this.label1.TabIndex = 26;
            this.label1.Text = "Logbook Record ID:";
            // 
            // logbk_mntxt
            // 
            this.logbk_mntxt.Location = new System.Drawing.Point(164, 88);
            this.logbk_mntxt.Name = "logbk_mntxt";
            this.logbk_mntxt.Size = new System.Drawing.Size(200, 20);
            this.logbk_mntxt.TabIndex = 24;
            this.logbk_mntxt.Leave += new System.EventHandler(this.logbk_mntxt_Leave);
            // 
            // logbk_lntxt
            // 
            this.logbk_lntxt.Location = new System.Drawing.Point(164, 114);
            this.logbk_lntxt.Name = "logbk_lntxt";
            this.logbk_lntxt.Size = new System.Drawing.Size(200, 20);
            this.logbk_lntxt.TabIndex = 23;
            this.logbk_lntxt.Leave += new System.EventHandler(this.logbk_lntxt_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 22);
            this.label9.TabIndex = 22;
            this.label9.Text = "Last Name:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 22);
            this.label8.TabIndex = 21;
            this.label8.Text = "Middle Name:";
            // 
            // logbk_clr_btn
            // 
            this.logbk_clr_btn.Location = new System.Drawing.Point(93, 244);
            this.logbk_clr_btn.Name = "logbk_clr_btn";
            this.logbk_clr_btn.Size = new System.Drawing.Size(75, 23);
            this.logbk_clr_btn.TabIndex = 20;
            this.logbk_clr_btn.Text = "Clear";
            this.logbk_clr_btn.UseVisualStyleBackColor = true;
            this.logbk_clr_btn.Click += new System.EventHandler(this.logbk_clr_btn_Click);
            // 
            // crit_cmb
            // 
            this.crit_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.crit_cmb.FormattingEnabled = true;
            this.crit_cmb.Items.AddRange(new object[] {
            "Staff_Name",
            "Username"});
            this.crit_cmb.Location = new System.Drawing.Point(388, 31);
            this.crit_cmb.Name = "crit_cmb";
            this.crit_cmb.Size = new System.Drawing.Size(148, 21);
            this.crit_cmb.TabIndex = 224;
            this.crit_cmb.SelectedIndexChanged += new System.EventHandler(this.crit_cmb_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(210, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(170, 22);
            this.label12.TabIndex = 222;
            this.label12.Text = "Search according to...";
            // 
            // dgv_clientlogbook
            // 
            this.dgv_clientlogbook.AllowUserToAddRows = false;
            this.dgv_clientlogbook.AllowUserToDeleteRows = false;
            this.dgv_clientlogbook.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_clientlogbook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_clientlogbook.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgv_clientlogbook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_clientlogbook.Location = new System.Drawing.Point(388, 58);
            this.dgv_clientlogbook.Name = "dgv_clientlogbook";
            this.dgv_clientlogbook.ReadOnly = true;
            this.dgv_clientlogbook.Size = new System.Drawing.Size(484, 291);
            this.dgv_clientlogbook.TabIndex = 218;
            this.dgv_clientlogbook.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_clientlogbook_CellClick);
            // 
            // logbk_upd_btn
            // 
            this.logbk_upd_btn.Enabled = false;
            this.logbk_upd_btn.Location = new System.Drawing.Point(12, 244);
            this.logbk_upd_btn.Name = "logbk_upd_btn";
            this.logbk_upd_btn.Size = new System.Drawing.Size(75, 23);
            this.logbk_upd_btn.TabIndex = 19;
            this.logbk_upd_btn.Text = "Update";
            this.logbk_upd_btn.UseVisualStyleBackColor = true;
            this.logbk_upd_btn.Click += new System.EventHandler(this.logbk_upd_btn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(8, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 22);
            this.label7.TabIndex = 18;
            this.label7.Text = "Time:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 189);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 22);
            this.label6.TabIndex = 13;
            this.label6.Text = "Date:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 22);
            this.label5.TabIndex = 12;
            this.label5.Text = "Contact Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 22);
            this.label4.TabIndex = 11;
            this.label4.Text = "Address:";
            // 
            // logbk_numb
            // 
            this.logbk_numb.Location = new System.Drawing.Point(166, 166);
            this.logbk_numb.MaxLength = 11;
            this.logbk_numb.Name = "logbk_numb";
            this.logbk_numb.Size = new System.Drawing.Size(200, 20);
            this.logbk_numb.TabIndex = 10;
            this.logbk_numb.Text = "09";
            this.logbk_numb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.logbk_numb_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 22);
            this.label3.TabIndex = 9;
            this.label3.Text = "First Name:";
            // 
            // logbk_pnl
            // 
            this.logbk_pnl.BackColor = System.Drawing.Color.SeaGreen;
            this.logbk_pnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.logbk_pnl.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logbk_pnl.ForeColor = System.Drawing.Color.Aquamarine;
            this.logbk_pnl.Location = new System.Drawing.Point(0, 0);
            this.logbk_pnl.Name = "logbk_pnl";
            this.logbk_pnl.Size = new System.Drawing.Size(375, 22);
            this.logbk_pnl.TabIndex = 8;
            this.logbk_pnl.Text = "CLIENT LOGBOOK INFORMATION";
            // 
            // logbk_fntxt
            // 
            this.logbk_fntxt.Location = new System.Drawing.Point(164, 62);
            this.logbk_fntxt.Name = "logbk_fntxt";
            this.logbk_fntxt.Size = new System.Drawing.Size(200, 20);
            this.logbk_fntxt.TabIndex = 7;
            this.logbk_fntxt.Leave += new System.EventHandler(this.logbk_fntxt_Leave);
            // 
            // logbk_addresstxt
            // 
            this.logbk_addresstxt.Location = new System.Drawing.Point(166, 140);
            this.logbk_addresstxt.Name = "logbk_addresstxt";
            this.logbk_addresstxt.Size = new System.Drawing.Size(200, 20);
            this.logbk_addresstxt.TabIndex = 1;
            this.logbk_addresstxt.Leave += new System.EventHandler(this.logbk_addresstxt_Leave);
            // 
            // logbook_pnl
            // 
            this.logbook_pnl.Controls.Add(this.logbk_timetxt);
            this.logbook_pnl.Controls.Add(this.logbk_datetxt);
            this.logbook_pnl.Controls.Add(this.idtxt);
            this.logbook_pnl.Controls.Add(this.label1);
            this.logbook_pnl.Controls.Add(this.logbk_mntxt);
            this.logbook_pnl.Controls.Add(this.logbk_lntxt);
            this.logbook_pnl.Controls.Add(this.label9);
            this.logbook_pnl.Controls.Add(this.label8);
            this.logbook_pnl.Controls.Add(this.logbk_clr_btn);
            this.logbook_pnl.Controls.Add(this.logbk_upd_btn);
            this.logbook_pnl.Controls.Add(this.label7);
            this.logbook_pnl.Controls.Add(this.label6);
            this.logbook_pnl.Controls.Add(this.label5);
            this.logbook_pnl.Controls.Add(this.label4);
            this.logbook_pnl.Controls.Add(this.logbk_numb);
            this.logbook_pnl.Controls.Add(this.label3);
            this.logbook_pnl.Controls.Add(this.logbk_pnl);
            this.logbook_pnl.Controls.Add(this.logbk_fntxt);
            this.logbook_pnl.Controls.Add(this.logbk_addresstxt);
            this.logbook_pnl.Location = new System.Drawing.Point(7, 58);
            this.logbook_pnl.Name = "logbook_pnl";
            this.logbook_pnl.Size = new System.Drawing.Size(375, 291);
            this.logbook_pnl.TabIndex = 225;
            // 
            // searchbtn
            // 
            this.searchbtn.Location = new System.Drawing.Point(773, 30);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(68, 23);
            this.searchbtn.TabIndex = 221;
            this.searchbtn.Text = "Search";
            this.searchbtn.UseVisualStyleBackColor = true;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // searchtxt
            // 
            this.searchtxt.Location = new System.Drawing.Point(542, 32);
            this.searchtxt.Name = "searchtxt";
            this.searchtxt.Size = new System.Drawing.Size(225, 20);
            this.searchtxt.TabIndex = 220;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.SeaGreen;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Aquamarine;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(884, 27);
            this.label2.TabIndex = 219;
            this.label2.Text = "SELECT CLIENT LOGBOOK INFORMATION";
            // 
            // ModifyClientLogbookDetails_Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ClientSize = new System.Drawing.Size(884, 361);
            this.Controls.Add(this.refbtn);
            this.Controls.Add(this.crit_cmb);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dgv_clientlogbook);
            this.Controls.Add(this.logbook_pnl);
            this.Controls.Add(this.searchbtn);
            this.Controls.Add(this.searchtxt);
            this.Controls.Add(this.label2);
            this.MaximumSize = new System.Drawing.Size(900, 400);
            this.MinimumSize = new System.Drawing.Size(900, 400);
            this.Name = "ModifyClientLogbookDetails_Staff";
            this.Text = "Modify Client Logbook Details";
            this.Load += new System.EventHandler(this.ModifyClientLogbookDetails_Staff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.refbtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_clientlogbook)).EndInit();
            this.logbook_pnl.ResumeLayout(false);
            this.logbook_pnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox refbtn;
        private System.Windows.Forms.Label logbk_timetxt;
        private System.Windows.Forms.DateTimePicker logbk_datetxt;
        private System.Windows.Forms.Label idtxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox logbk_mntxt;
        private System.Windows.Forms.TextBox logbk_lntxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button logbk_clr_btn;
        private System.Windows.Forms.ComboBox crit_cmb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgv_clientlogbook;
        private System.Windows.Forms.Button logbk_upd_btn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox logbk_numb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label logbk_pnl;
        private System.Windows.Forms.TextBox logbk_fntxt;
        private System.Windows.Forms.TextBox logbk_addresstxt;
        private System.Windows.Forms.Panel logbook_pnl;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.TextBox searchtxt;
        private System.Windows.Forms.Label label2;
    }
}