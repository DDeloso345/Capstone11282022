﻿using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Capstone
{
    public class SQLAdminCommandsClass
    {
        public List<AccountDetails_Get> LoadAdminData()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<AccountDetails_Get>($"SELECT emp.id, emp.FirstName, emp.MiddleName, emp.LastName, s.Suffix, ep.Position, er.EmpRoles, emp.EMailAddress, emp.ContactNo, emp.Username, emp.Password, emp.ImgPath, es.ActiveStatus "
                                + "FROM emp_info_main emp "
                                + "INNER JOIN name_suffix s "
                                + "ON(emp.Suffix = s.id) "
                                + "INNER JOIN EmpRoles er "
                                + "ON(emp.EmpRoles = er.id) "
                                + "INNER JOIN EmpPosition ep "
                                + "ON(emp.Position = ep.id) "
                                + "INNER JOIN EmpStatus es "
                                + "ON(emp.ActiveStatus = es.id)"
                                + "where emp.EmpRoles = '1'").ToList();
                return output;
            }
        }
    }
}
