﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Staff_MemberBorrowedBooksReport : Form
    {
        public Staff_MemberBorrowedBooksReport()
        {
            InitializeComponent();
        }
    }
}
