﻿
namespace Capstone
{
    partial class Admin_DashboardUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.firstnametxt = new System.Windows.Forms.Label();
            this.lastnametxt = new System.Windows.Forms.Label();
            this.middlenametxt = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.positiontxt = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.hierarchylvltxt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.usernametxt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.emailtxt = new System.Windows.Forms.Label();
            this.dashboard_pnl = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.missingbk = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.expmemb = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lgbk_now = new System.Windows.Forms.Label();
            this.logbook = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.curr_availbk = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.month_bkbr = new System.Windows.Forms.Label();
            this.totalbkbr = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.profimg = new System.Windows.Forms.PictureBox();
            this.modifylogbk = new System.Windows.Forms.Button();
            this.dashboard_pnl.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profimg)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(218, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "First Name:";
            // 
            // firstnametxt
            // 
            this.firstnametxt.AutoSize = true;
            this.firstnametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstnametxt.Location = new System.Drawing.Point(356, 12);
            this.firstnametxt.Name = "firstnametxt";
            this.firstnametxt.Size = new System.Drawing.Size(76, 25);
            this.firstnametxt.TabIndex = 3;
            this.firstnametxt.Text = "label1";
            // 
            // lastnametxt
            // 
            this.lastnametxt.AutoSize = true;
            this.lastnametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastnametxt.Location = new System.Drawing.Point(355, 62);
            this.lastnametxt.Name = "lastnametxt";
            this.lastnametxt.Size = new System.Drawing.Size(76, 25);
            this.lastnametxt.TabIndex = 4;
            this.lastnametxt.Text = "label3";
            // 
            // middlenametxt
            // 
            this.middlenametxt.AutoSize = true;
            this.middlenametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middlenametxt.Location = new System.Drawing.Point(381, 37);
            this.middlenametxt.Name = "middlenametxt";
            this.middlenametxt.Size = new System.Drawing.Size(76, 25);
            this.middlenametxt.TabIndex = 5;
            this.middlenametxt.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(218, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Position:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(218, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 25);
            this.label6.TabIndex = 7;
            this.label6.Text = "Last Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(218, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 25);
            this.label7.TabIndex = 8;
            this.label7.Text = "Middle Name:";
            // 
            // positiontxt
            // 
            this.positiontxt.AutoSize = true;
            this.positiontxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positiontxt.Location = new System.Drawing.Point(327, 87);
            this.positiontxt.Name = "positiontxt";
            this.positiontxt.Size = new System.Drawing.Size(76, 25);
            this.positiontxt.TabIndex = 9;
            this.positiontxt.Text = "label8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(218, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(184, 25);
            this.label9.TabIndex = 10;
            this.label9.Text = "Hierarchy Level:";
            // 
            // hierarchylvltxt
            // 
            this.hierarchylvltxt.AutoSize = true;
            this.hierarchylvltxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hierarchylvltxt.Location = new System.Drawing.Point(409, 112);
            this.hierarchylvltxt.Name = "hierarchylvltxt";
            this.hierarchylvltxt.Size = new System.Drawing.Size(89, 25);
            this.hierarchylvltxt.TabIndex = 11;
            this.hierarchylvltxt.Text = "label10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 215);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Username: ";
            // 
            // usernametxt
            // 
            this.usernametxt.AutoSize = true;
            this.usernametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernametxt.Location = new System.Drawing.Point(135, 215);
            this.usernametxt.Name = "usernametxt";
            this.usernametxt.Size = new System.Drawing.Size(76, 25);
            this.usernametxt.TabIndex = 14;
            this.usernametxt.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(219, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "E-mail:";
            // 
            // emailtxt
            // 
            this.emailtxt.AutoSize = true;
            this.emailtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtxt.Location = new System.Drawing.Point(296, 137);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(89, 25);
            this.emailtxt.TabIndex = 16;
            this.emailtxt.Text = "label10";
            // 
            // dashboard_pnl
            // 
            this.dashboard_pnl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dashboard_pnl.Controls.Add(this.panel6);
            this.dashboard_pnl.Controls.Add(this.panel5);
            this.dashboard_pnl.Controls.Add(this.panel4);
            this.dashboard_pnl.Controls.Add(this.panel3);
            this.dashboard_pnl.Controls.Add(this.panel2);
            this.dashboard_pnl.Controls.Add(this.panel1);
            this.dashboard_pnl.Location = new System.Drawing.Point(12, 243);
            this.dashboard_pnl.Name = "dashboard_pnl";
            this.dashboard_pnl.Size = new System.Drawing.Size(960, 366);
            this.dashboard_pnl.TabIndex = 17;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel6.Controls.Add(this.missingbk);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Location = new System.Drawing.Point(332, 15);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 160);
            this.panel6.TabIndex = 3;
            // 
            // missingbk
            // 
            this.missingbk.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.missingbk.Location = new System.Drawing.Point(93, 69);
            this.missingbk.Name = "missingbk";
            this.missingbk.Size = new System.Drawing.Size(195, 66);
            this.missingbk.TabIndex = 9;
            this.missingbk.Text = "Books Borrowed for this Month:";
            this.missingbk.Click += new System.EventHandler(this.missingbk_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(93, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(195, 66);
            this.label8.TabIndex = 4;
            this.label8.Text = "Missing Books:";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Capstone.Properties.Resources._150361;
            this.pictureBox6.Location = new System.Drawing.Point(0, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(87, 154);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel5.Controls.Add(this.expmemb);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Location = new System.Drawing.Point(644, 15);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(300, 160);
            this.panel5.TabIndex = 6;
            // 
            // expmemb
            // 
            this.expmemb.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expmemb.Location = new System.Drawing.Point(93, 69);
            this.expmemb.Name = "expmemb";
            this.expmemb.Size = new System.Drawing.Size(195, 66);
            this.expmemb.TabIndex = 10;
            this.expmemb.Text = "Members";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(96, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 66);
            this.label4.TabIndex = 3;
            this.label4.Text = "Expired Members:";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Capstone.Properties.Resources._2851439__1_;
            this.pictureBox5.Location = new System.Drawing.Point(0, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(90, 154);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel4.Controls.Add(this.lgbk_now);
            this.panel4.Controls.Add(this.logbook);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Location = new System.Drawing.Point(644, 190);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(300, 160);
            this.panel4.TabIndex = 5;
            // 
            // lgbk_now
            // 
            this.lgbk_now.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgbk_now.Location = new System.Drawing.Point(88, 59);
            this.lgbk_now.Name = "lgbk_now";
            this.lgbk_now.Size = new System.Drawing.Size(195, 66);
            this.lgbk_now.TabIndex = 11;
            this.lgbk_now.Text = "Books Borrowed for this Month:";
            // 
            // logbook
            // 
            this.logbook.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logbook.Location = new System.Drawing.Point(239, 141);
            this.logbook.Name = "logbook";
            this.logbook.Size = new System.Drawing.Size(58, 16);
            this.logbook.TabIndex = 10;
            this.logbook.Text = "[books]";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(89, 128);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(144, 32);
            this.label16.TabIndex = 9;
            this.label16.Text = "Total # of walk-in clients received:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(93, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(195, 66);
            this.label13.TabIndex = 8;
            this.label13.Text = "Walk-in Clients for Today:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Capstone.Properties.Resources._1468450_200;
            this.pictureBox4.Location = new System.Drawing.Point(0, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(87, 154);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel3.Controls.Add(this.curr_availbk);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Location = new System.Drawing.Point(332, 190);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 160);
            this.panel3.TabIndex = 4;
            // 
            // curr_availbk
            // 
            this.curr_availbk.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curr_availbk.Location = new System.Drawing.Point(96, 79);
            this.curr_availbk.Name = "curr_availbk";
            this.curr_availbk.Size = new System.Drawing.Size(195, 66);
            this.curr_availbk.TabIndex = 10;
            this.curr_availbk.Text = "Books Borrowed for this Month:";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(96, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(195, 66);
            this.label12.TabIndex = 7;
            this.label12.Text = "Current Available Books:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Capstone.Properties.Resources.kindpng_3286450;
            this.pictureBox3.Location = new System.Drawing.Point(0, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(87, 154);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(14, 190);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 160);
            this.panel2.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(91, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(195, 66);
            this.label11.TabIndex = 6;
            this.label11.Text = "label11";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Capstone.Properties.Resources.noun_85138;
            this.pictureBox2.Location = new System.Drawing.Point(0, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(87, 154);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.month_bkbr);
            this.panel1.Controls.Add(this.totalbkbr);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(14, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 160);
            this.panel1.TabIndex = 1;
            // 
            // month_bkbr
            // 
            this.month_bkbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.month_bkbr.Location = new System.Drawing.Point(104, 69);
            this.month_bkbr.Name = "month_bkbr";
            this.month_bkbr.Size = new System.Drawing.Size(195, 53);
            this.month_bkbr.TabIndex = 8;
            this.month_bkbr.Text = "Books Borrowed for this Month:";
            // 
            // totalbkbr
            // 
            this.totalbkbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalbkbr.Location = new System.Drawing.Point(242, 141);
            this.totalbkbr.Name = "totalbkbr";
            this.totalbkbr.Size = new System.Drawing.Size(58, 16);
            this.totalbkbr.TabIndex = 7;
            this.totalbkbr.Text = "[books]";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(94, 133);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 35);
            this.label14.TabIndex = 6;
            this.label14.Text = "Total # of currently borrowed books:";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(96, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(195, 66);
            this.label10.TabIndex = 5;
            this.label10.Text = "Books Borrowed for this Month:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Capstone.Properties.Resources.noun_85138;
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 154);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // profimg
            // 
            this.profimg.Location = new System.Drawing.Point(12, 12);
            this.profimg.Name = "profimg";
            this.profimg.Size = new System.Drawing.Size(200, 200);
            this.profimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profimg.TabIndex = 0;
            this.profimg.TabStop = false;
            // 
            // modifylogbk
            // 
            this.modifylogbk.Location = new System.Drawing.Point(814, 12);
            this.modifylogbk.Name = "modifylogbk";
            this.modifylogbk.Size = new System.Drawing.Size(158, 23);
            this.modifylogbk.TabIndex = 18;
            this.modifylogbk.Text = "button1";
            this.modifylogbk.UseVisualStyleBackColor = true;
            // 
            // Admin_DashboardUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(984, 621);
            this.Controls.Add(this.modifylogbk);
            this.Controls.Add(this.dashboard_pnl);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.usernametxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hierarchylvltxt);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.positiontxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.middlenametxt);
            this.Controls.Add(this.lastnametxt);
            this.Controls.Add(this.firstnametxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.profimg);
            this.Name = "Admin_DashboardUI";
            this.Text = "Admin_DashboardUI";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Admin_DashboardUI_FormClosing);
            this.Load += new System.EventHandler(this.Admin_DashboardUI_Load);
            this.dashboard_pnl.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profimg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox profimg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label usernametxt;
        private System.Windows.Forms.Label lastnametxt;
        private System.Windows.Forms.Label middlenametxt;
        private System.Windows.Forms.Label positiontxt;
        private System.Windows.Forms.Label hierarchylvltxt;
        private System.Windows.Forms.Label firstnametxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label emailtxt;
        private System.Windows.Forms.Panel dashboard_pnl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label month_bkbr;
        private System.Windows.Forms.Label totalbkbr;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label missingbk;
        private System.Windows.Forms.Label curr_availbk;
        private System.Windows.Forms.Label expmemb;
        private System.Windows.Forms.Label lgbk_now;
        private System.Windows.Forms.Label logbook;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button modifylogbk;
    }
}