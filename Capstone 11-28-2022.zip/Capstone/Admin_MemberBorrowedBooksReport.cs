﻿using System.Windows.Forms;

namespace Capstone
{
    public partial class Admin_MemberBorrowedBooksReport : Form
    {
        public Admin_MemberBorrowedBooksReport()
        {
            InitializeComponent();
        }
    }
}
